NAME: Ethan Coles
ID: 0843081
ASSIGNMENT #: 2

********How to run programs********
To compile type make.

To run, type, ./q1 records.txt.
records.txt is the list file that is comma delimited.  

To run q2, type ./q2 <Equation>

********Sample Output********
q1:
********TO*RENT********
PLATE #: 640PMG
MILEAGE (KM): 5

PLATE #: 697BBJ
MILEAGE (KM): 10

PLATE #: 4HFX108
MILEAGE (KM): 20

PLATE #: 822GBR
MILEAGE (KM): 30

q2:
Answer: 5
