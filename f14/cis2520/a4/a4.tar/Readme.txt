NAME: Ethan Coles
ID: 0843081
ASSIGNMENT #: 4

********How to run programs********
To compile type make.

The source code is in separate files, but is all compiled into one executable.

To run, type, ./avltree

********Sample Output********
**********************
*-----MAIN MENU------*
* Ethan Coles        *
* 0843081            *
**********************
1)Initialization
2)Find
3)Insert
4)Remove
5)Check Height and Size
6)Find All(above a given frequency)
7)Exit
avl/> 
.
.
.
find key: flr549
key: flr549, frequency: 5590
