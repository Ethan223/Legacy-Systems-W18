/***************************
Name: Ethan Coles
ID: 0843081
Date: 09/29/2014
Assignment Name: Assignment 1, #1
****************************/
#include <stdio.h>
#include <stdlib.h>

void carbon()
{
    int i, j, k, l, m, n;

    for(i=0; i<6; i++)
    {
        for(j=0; j<6; j++)
        {
            for(k=0; k<6; k++)
            {
                for(l=0; l<6; l++)
                {
                    for(m=0; m<6; m++)
                    {
                        for(n=0; n<6; n++)
                        {
                            if(i != j && i != k && i != l && i != m && i != n && j != k && j != l && j != m && j != n && k != l && k != m && k != n && l != m && l != n && n != m)
                            {                                  
                                    switch(i)    /*Converts arrangment of numbers into letters*/
                                    {
                                        case 0:
                                          printf("c");
                                          break;
                                        case 1:
                                          printf("a");
                                          break;
                                        case 2:
                                          printf("r");
                                          break;
                                        case 3:
                                          printf("b");
                                          break;
                                        case 4:
                                          printf("o");
                                          break;
                                        case 5:
                                          printf("n");
                                          break;
                                    }
                                    switch(j)
                                    {
                                        case 0:
                                          printf("c");
                                          break;
                                        case 1:
                                          printf("a");
                                          break;
                                        case 2:
                                          printf("r");
                                          break;
                                        case 3:
                                          printf("b");
                                          break;
                                        case 4:
                                          printf("o");
                                          break;
                                        case 5:
                                          printf("n");
                                          break;
                                    }
                                    switch(k)
                                    {
                                        case 0:
                                          printf("c");
                                          break;
                                        case 1:
                                          printf("a");
                                          break;
                                        case 2:
                                          printf("r");
                                          break;
                                        case 3:
                                          printf("b");
                                          break;
                                        case 4:
                                          printf("o");
                                          break;
                                        case 5:
                                          printf("n");
                                          break;
                                    }
                                    switch(l)
                                    {
                                        case 0:
                                          printf("c");
                                          break;
                                        case 1:
                                          printf("a");
                                          break;
                                        case 2:
                                          printf("r");
                                          break;
                                        case 3:
                                          printf("b");
                                          break;
                                        case 4:
                                          printf("o");
                                          break;
                                        case 5:
                                          printf("n");
                                          break;
                                    }
                                    switch(m)
                                    {
                                        case 0:
                                          printf("c");
                                          break;
                                        case 1:
                                          printf("a");
                                          break;
                                        case 2:
                                          printf("r");
                                          break;
                                        case 3:
                                          printf("b");
                                          break;
                                        case 4:
                                          printf("o");
                                          break;
                                        case 5:
                                          printf("n");
                                          break;
                                    }
                                    switch(n)
                                    {
                                        case 0:
                                          printf("c");
                                          break;
                                        case 1:
                                          printf("a");
                                          break;
                                        case 2:
                                          printf("r");
                                          break;
                                        case 3:
                                          printf("b");
                                          break;
                                        case 4:
                                          printf("o");
                                          break;
                                        case 5:
                                          printf("n");
                                          break;
                                    }
                                    
                                    printf("\n");    
                                } 
                        }
                    }
                }     
            }
        }	
    }
}
